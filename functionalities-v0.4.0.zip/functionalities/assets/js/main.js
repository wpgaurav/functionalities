(function(){
	'use strict';
	// Functionalities plugin JS bootstrap
	if (typeof window !== 'undefined') {
		console.debug('[functionalities] assets loaded');
	}
})();
